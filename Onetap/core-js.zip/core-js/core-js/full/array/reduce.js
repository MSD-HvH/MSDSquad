var parent = require('../../actual/array/reduce');

module.exports = parent;
