var parent = require('../../actual/array/concat');

module.exports = parent;
