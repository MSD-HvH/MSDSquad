var parent = require('../../actual/array/flat');

module.exports = parent;
