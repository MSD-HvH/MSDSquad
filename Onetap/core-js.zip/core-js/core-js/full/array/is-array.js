var parent = require('../../actual/array/is-array');

module.exports = parent;
