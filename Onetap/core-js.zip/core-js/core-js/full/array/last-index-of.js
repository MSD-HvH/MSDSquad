var parent = require('../../actual/array/last-index-of');

module.exports = parent;
