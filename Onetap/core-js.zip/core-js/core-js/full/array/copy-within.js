var parent = require('../../actual/array/copy-within');

module.exports = parent;
