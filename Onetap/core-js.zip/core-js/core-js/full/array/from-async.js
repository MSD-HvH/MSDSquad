var parent = require('../../actual/array/from-async');

module.exports = parent;
