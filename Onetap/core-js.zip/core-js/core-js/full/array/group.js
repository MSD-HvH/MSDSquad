var parent = require('../../actual/array/group');

module.exports = parent;
