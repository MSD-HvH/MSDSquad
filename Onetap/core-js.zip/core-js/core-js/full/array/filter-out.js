// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.filter-out');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'filterOut');
