var parent = require('../../actual/array/push');

module.exports = parent;
