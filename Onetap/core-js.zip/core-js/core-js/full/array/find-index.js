var parent = require('../../actual/array/find-index');

module.exports = parent;
