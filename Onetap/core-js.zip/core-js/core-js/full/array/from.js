var parent = require('../../actual/array/from');

module.exports = parent;
