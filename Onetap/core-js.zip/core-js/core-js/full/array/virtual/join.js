var parent = require('../../../actual/array/virtual/join');

module.exports = parent;
