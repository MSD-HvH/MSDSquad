var parent = require('../../../actual/array/virtual/every');

module.exports = parent;
