var parent = require('../../../actual/array/virtual/find');

module.exports = parent;
