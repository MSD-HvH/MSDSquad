var parent = require('../../../actual/array/virtual/group-to-map');

module.exports = parent;
