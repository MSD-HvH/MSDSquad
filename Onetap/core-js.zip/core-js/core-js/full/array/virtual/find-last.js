var parent = require('../../../actual/array/virtual/find-last');

module.exports = parent;
