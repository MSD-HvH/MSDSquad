var parent = require('../../../actual/array/virtual/last-index-of');

module.exports = parent;
