var parent = require('../../../actual/array/virtual/group');

module.exports = parent;
