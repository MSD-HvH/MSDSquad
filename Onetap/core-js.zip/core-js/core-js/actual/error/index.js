var parent = require('../../stable/error');

module.exports = parent;
