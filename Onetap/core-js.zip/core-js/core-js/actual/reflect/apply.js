var parent = require('../../stable/reflect/apply');

module.exports = parent;
