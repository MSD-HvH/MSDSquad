var parent = require('../../stable/reflect/own-keys');

module.exports = parent;
