var parent = require('../../stable/array/sort');

module.exports = parent;
