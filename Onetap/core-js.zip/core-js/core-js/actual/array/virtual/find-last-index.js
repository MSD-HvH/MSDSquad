require('../../../modules/esnext.array.find-last-index');
var parent = require('../../../stable/array/virtual/find-last-index');

module.exports = parent;
