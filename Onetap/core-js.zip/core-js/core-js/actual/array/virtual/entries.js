var parent = require('../../../stable/array/virtual/entries');

module.exports = parent;
