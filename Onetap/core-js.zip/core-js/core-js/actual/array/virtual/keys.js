var parent = require('../../../stable/array/virtual/keys');

module.exports = parent;
