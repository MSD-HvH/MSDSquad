var parent = require('../../../stable/array/virtual/index-of');

module.exports = parent;
