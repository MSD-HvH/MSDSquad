var parent = require('../../../stable/array/virtual/flat');

module.exports = parent;
