require('../../../modules/es.map');
require('../../../modules/es.object.to-string');
require('../../../modules/esnext.array.group-to-map');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').groupToMap;
