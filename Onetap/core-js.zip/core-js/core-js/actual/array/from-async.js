require('../../modules/es.array.iterator');
require('../../modules/es.object.to-string');
require('../../modules/es.promise');
require('../../modules/es.string.iterator');
require('../../modules/esnext.array.from-async');
var path = require('../../internals/path');

module.exports = path.Array.fromAsync;
