var parent = require('../../stable/array/entries');

module.exports = parent;
