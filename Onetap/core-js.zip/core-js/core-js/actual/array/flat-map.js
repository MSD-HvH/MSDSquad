var parent = require('../../stable/array/flat-map');

module.exports = parent;
