var parent = require('../../stable/array/slice');

module.exports = parent;
