var parent = require('../../stable/math/cosh');

module.exports = parent;
