var parent = require('../stable/parse-float');

module.exports = parent;
