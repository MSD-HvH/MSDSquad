var parent = require('../../stable/typed-array/to-string');

module.exports = parent;
