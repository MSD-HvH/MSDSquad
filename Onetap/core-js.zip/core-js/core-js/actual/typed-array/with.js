require('../../modules/esnext.typed-array.with');
