var parent = require('../../stable/dom-exception/constructor');

module.exports = parent;
