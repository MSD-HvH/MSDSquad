var parent = require('../../stable/string/pad-end');

module.exports = parent;
