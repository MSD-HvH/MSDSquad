var parent = require('../../stable/string/strike');

module.exports = parent;
