var parent = require('../../../stable/string/virtual/pad-start');

module.exports = parent;
