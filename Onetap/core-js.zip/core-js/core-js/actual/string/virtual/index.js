var parent = require('../../../stable/string/virtual');

module.exports = parent;
