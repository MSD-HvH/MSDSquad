var parent = require('../../../stable/string/virtual/trim-left');

module.exports = parent;
