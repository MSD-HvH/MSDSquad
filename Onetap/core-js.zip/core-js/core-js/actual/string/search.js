var parent = require('../../stable/string/search');

module.exports = parent;
