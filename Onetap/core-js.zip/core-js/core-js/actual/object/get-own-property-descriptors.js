var parent = require('../../stable/object/get-own-property-descriptors');

module.exports = parent;
