var parent = require('../../stable/object/values');

module.exports = parent;
