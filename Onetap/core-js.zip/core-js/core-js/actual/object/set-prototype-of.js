var parent = require('../../stable/object/set-prototype-of');

module.exports = parent;
