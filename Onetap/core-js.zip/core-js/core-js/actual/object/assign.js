var parent = require('../../stable/object/assign');

module.exports = parent;
