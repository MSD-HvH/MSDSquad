var parent = require('../../stable/object/proto');

module.exports = parent;
