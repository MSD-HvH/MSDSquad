var parent = require('../../stable/regexp/dot-all');

module.exports = parent;
