var parent = require('../../stable/regexp/sticky');

module.exports = parent;
