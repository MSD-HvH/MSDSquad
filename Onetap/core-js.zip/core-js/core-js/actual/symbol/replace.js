var parent = require('../../stable/symbol/replace');

module.exports = parent;
