var parent = require('../../stable/symbol/species');

module.exports = parent;
