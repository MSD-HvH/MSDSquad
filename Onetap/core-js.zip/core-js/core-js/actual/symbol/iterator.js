var parent = require('../../stable/symbol/iterator');

module.exports = parent;
