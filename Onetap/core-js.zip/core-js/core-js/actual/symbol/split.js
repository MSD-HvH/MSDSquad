var parent = require('../../stable/symbol/split');

module.exports = parent;
