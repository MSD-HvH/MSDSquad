var parent = require('../../stable/symbol/match-all');

module.exports = parent;
