var parent = require('../../stable/number');

module.exports = parent;
