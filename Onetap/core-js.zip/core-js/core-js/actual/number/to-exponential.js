var parent = require('../../stable/number/to-exponential');

module.exports = parent;
