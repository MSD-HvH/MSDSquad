var parent = require('../../stable/number/constructor');

module.exports = parent;
