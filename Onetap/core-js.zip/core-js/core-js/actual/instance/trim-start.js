var parent = require('../../stable/instance/trim-start');

module.exports = parent;
