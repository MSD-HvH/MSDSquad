var parent = require('../../stable/instance/trim');

module.exports = parent;
