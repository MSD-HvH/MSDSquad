var parent = require('../../stable/instance/for-each');

module.exports = parent;
